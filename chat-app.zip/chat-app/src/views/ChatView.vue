<template>
  <div class="chat-container">
    <!-- Contact List -->
    <div class="contact-list">
      <div
        v-for="contact in contacts"
        :key="contact.id"
        :class="['contact', { active: contact.id === selectedContact?.id }]"
        @click="selectContact(contact)"
      >
        <span>{{ contact.name }}</span>
        <span class="status" :class="contact.online ? 'online' : 'offline'"></span>
      </div>
    </div>

    <!-- Chat Panel -->
    <div class="chat-panel" v-if="selectedContact">
      <div class="chat-header">
        <h3>{{ selectedContact.name }}</h3>
      </div>

      <div class="chat-messages">
        <div
          v-for="(msg, index) in messages"
          :key="index"
          :class="['chat-message', msg.failed ? 'failed' : '']"
        >
          <span>{{ msg.text }}</span>
          <span v-if="msg.failed" class="error">❗️</span>
        </div>
      </div>

      <div class="chat-input">
        <input v-model="newMessage" @keydown.enter="sendMessage" placeholder="Type a message..." />
        <input type="file" @change="sendFile" />
        <button @click="sendMessage">Send</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "ChatView",
  data() {
    return {
      contacts: [
        { id: 1, name: "Alice", online: true },
        { id: 2, name: "Bob", online: false },
      ],
      selectedContact: null,
      newMessage: "",
      messages: [],
    };
  },
  methods: {
    selectContact(contact) {
      this.selectedContact = contact;
      this.loadMessages(contact.id);
    },
    loadMessages(contactId) {
      // TODO: Load messages from local DB based on contactId
      this.messages = [];
    },
    sendMessage() {
      if (!this.newMessage.trim()) return;

      const msg = {
        text: this.newMessage.trim(),
        failed: !this.selectedContact.online,
        timestamp: new Date(),
      };
      this.messages.push(msg);
      this.newMessage = "";

      if (!msg.failed) {
        // TODO: Send to server or WebSocket
      }
    },
    sendFile(event) {
      const file = event.target.files[0];
      if (!file) return;

      const msg = {
        text: `[File] ${file.name}`,
        failed: !this.selectedContact.online,
        timestamp: new Date(),
      };
      this.messages.push(msg);

      if (!msg.failed) {
        // TODO: Upload and send file to server
      }
    },
  },
};
</script>

<style scoped>
.chat-container {
  display: flex;
  height: 100vh;
  font-family: sans-serif;
}

/* Left panel: Contact list */
.contact-list {
  width: 250px;
  background-color: #f2f2f2;
  padding: 10px;
  overflow-y: auto;
}

.contact {
  padding: 10px;
  cursor: pointer;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.contact.active {
  background-color: #e6e6e6;
  font-weight: bold;
}

.status {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  display: inline-block;
}

.status.online {
  background-color: green;
}

.status.offline {
  border: 2px solid gray;
  background-color: white;
}

/* Right panel: Chat */
.chat-panel {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.chat-header {
  padding: 10px;
  border-bottom: 1px solid #ccc;
}

.chat-messages {
  flex: 1;
  padding: 10px;
  overflow-y: auto;
  background: #fff;
}

.chat-message {
  margin-bottom: 10px;
  background: #f1f1f1;
  padding: 8px;
  border-radius: 5px;
}

.chat-message.failed {
  background-color: #ffe5e5;
  border: 1px solid red;
}

.error {
  color: red;
  margin-left: 5px;
  font-weight: bold;
}

.chat-input {
  display: flex;
  gap: 10px;
  padding: 10px;
  border-top: 1px solid #ccc;
}

.chat-input input[type="text"] {
  flex: 1;
  padding: 5px;
}
</style>