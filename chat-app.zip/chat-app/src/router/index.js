import { createRouter, createWebHistory } from 'vue-router'
import Auth from '../components/Auth.vue'
import ChatView from '../views/ChatView.vue'

const routes = [
  { path: '/', component: Auth },
  { path: '/chat', component: ChatView }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router